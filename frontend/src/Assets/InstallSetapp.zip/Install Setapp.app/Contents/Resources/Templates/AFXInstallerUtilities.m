#import "AFXInstallerUtilities.h"
#import "AFXCurrentInstallerInfo.h"
@import ObjCTools;
@import SetappInterface;

#pragma mark - Public

NSURL *AFXGetZipDownloadURL(void)
{
    return [NSURL URLWithString:@"%{INSTALLER_ZIP_DL_URL}"];
}

NSURL *AFXGetDmgDownloadURL(void)
{
    return [NSURL URLWithString:@"%{INSTALLER_DMG_DL_URL}"];
}

NSURL *AFXGetAWSZipDownloadURL(void)
{
    return [NSURL URLWithString:@"%{AWS_DISCOVERY_URL}"];
}

NSString *AFXGetProductName(void)
{
  return @"%{PRODUCT_NAME}";
}
